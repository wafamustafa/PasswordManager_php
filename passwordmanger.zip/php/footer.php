<footer>
    <div class="borderDiv"></div>
    <nav class="footerNav">
        <ul>
            <li><a href="<?php echo 'clientAboutUs.php'; ?>">About Us</a></li>
            <li><a href="<?php echo 'clientFAQ.php'; ?>">FAQ</a></li>
            <li><a href="<?php echo 'listContactMessages.php'; ?>">Contact Us</a></li>
        </ul>
    </nav>
</footer>