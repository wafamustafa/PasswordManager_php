
<nav id="accountNav" class="accountNav">
    <ul>
    <li><a href="<?php echo 'listPasswords.php'; ?>">Passwords</a></li>
    <li><a href="<?php echo 'profile.php'; ?>">Profile</a></li>
    <li><a href="<?php echo 'listSharing.php'; ?>">Sharing</a></li>
    <li><a href="<?php echo 'import.php'; ?>">Import</a></li>
    <li><a href="<?php echo 'export.php'; ?>">Export</a></li>
    <li><a href="<?php echo 'historyMain.php'; ?>">History</a></li>
    <li><a href="<?php echo 'recoveryInformation.php'; ?>">Recovery</a></li>
    </ul>
</nav>